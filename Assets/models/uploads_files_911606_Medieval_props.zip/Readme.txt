Medieval props - lowpoly by alpha16

A perfect small package to adapt to your medieval project. Great for games and compatible with mobiles and VR.



7 meshes / textures 1024*1024



Mesh list:

- spear (176 polys/ 316 tris)

- barrel (750 polys/ 750 tris)

- crate (12 polys/ 12 tris)

- crossbow (878 polys/ 1678 tris)

- 1 handed sword (136 polys/ 254 tris)

- 2 handed sword (136 polys/ 254 tris)

- weapons rack (197 polys/ 397 tris)



Available formats :

- FBX

- OBJ

For any problem please contact me at : contact@alphas-projects.com
My medias :

Youtube : https://www.youtube.com/channel/UCpew1dEJgqJKxdhgItX6gQA
Twitter : https://twitter.com/AlphAIFr
Artstation : https://www.artstation.com/alpha16
Sketchfab : https://sketchfab.com/alpha-fr/models